"""Agente local do Exiros: roda no SEU computador, com o SEU Teams logado.

O que ele faz, enquanto estiver aberto:
  1. A cada minuto avisa o app que está online (tabela exiros_agente).
  2. Atende os pedidos do botão "Atualizar RCs" do app, quando o administrador escolhe "Neste computador".
  3. Na janela automática (padrão 12:00-13:00, segunda a sexta) atualiza sozinho se ainda não houve
     atualização completa com sucesso no dia. Sábado e domingo não rodam sozinhos; o botão funciona sempre.

Uso:
  python agente_local.py            -> fica rodando (é o que o iniciar_exiros.bat faz)
  python agente_local.py --login    -> abre o Chrome para você entrar no Teams (só na primeira vez ou se a sessão cair)
  python agente_local.py --agora    -> atualiza todas as RCs agora e sai (se o agente já estiver aberto, só faz o pedido a ele)

Códigos de saída: 0 = ok, 3 = parada intencional ou já existe um agente aberto (o .bat não reinicia).
"""
import argparse
import os
import re
import socket
import sys
import threading
import time
import traceback
from datetime import datetime, timedelta, timezone

from playwright.sync_api import sync_playwright

from exiros_common import CONTEXT_OPTS, TEAMS_URL, agora, rest
import exiros_sync as sync

VERSAO = "1.0"
POLL_SEG = int(os.environ.get("EXIROS_POLL_SEG", "60"))
JANELA_INI = os.environ.get("EXIROS_JANELA_INICIO", "12:00")
JANELA_FIM = os.environ.get("EXIROS_JANELA_FIM", "13:00")
DIAS_AUTO = {int(d) for d in os.environ.get("EXIROS_DIAS_AUTO", "0,1,2,3,4").split(",") if d.strip() != ""}  # 0=seg ... 6=dom
PEDIDO_VALIDADE_MIN = 30      # pedido que ficou esperando mais que isso (agente fora do ar) é descartado
AUTO_MAX_TENTATIVAS = 3       # por dia
AUTO_INTERVALO_MIN = 15       # entre tentativas automáticas
PORTA_TRAVA = 48765           # impede dois agentes ao mesmo tempo no mesmo PC
MAQUINA = socket.gethostname()

try:
    sys.stdout.reconfigure(errors="replace")
    sys.stderr.reconfigure(errors="replace")
except Exception:
    pass


def log(msg):
    print(f"[{datetime.now():%d/%m %H:%M:%S}] {msg}", flush=True)


def _iso_z(dt):
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------- batimento (o app lê isto para saber se o agente está online) ----------
_estado = {"v": "ocioso"}


def _ping():
    rest("POST", "exiros_agente?on_conflict=id",
         {"id": "principal", "ultimo_ping": agora(), "versao": VERSAO, "maquina": MAQUINA, "estado": _estado["v"]},
         prefer="resolution=merge-duplicates,return=minimal")


def definir_estado(novo):
    _estado["v"] = novo
    try:
        _ping()
    except Exception as e:
        log(f"(batimento falhou: {e})")


def _batimento_loop():
    while True:
        try:
            _ping()
        except Exception as e:
            log(f"(batimento falhou: {e})")
        time.sleep(30)


# ---------- botão "Parar" do app ----------
def parar_solicitado():
    try:
        rows = rest("GET", "exiros_agente?id=eq.principal&select=parar")
        return bool(rows and rows[0].get("parar"))
    except Exception:
        return False


def limpar_parar():
    try:
        rest("PATCH", "exiros_agente?id=eq.principal", {"parar": False}, prefer="return=minimal")
    except Exception:
        pass


# ---------- login ----------
def _chrome_visivel(p):
    os.makedirs(sync.PERFIL_DIR, exist_ok=True)
    return p.chromium.launch_persistent_context(
        sync.PERFIL_DIR, channel="chrome", headless=False,
        args=["--disable-blink-features=AutomationControlled"], **CONTEXT_OPTS)


def login_manual():
    """Primeira vez: você faz o login (e-mail, senha, MFA) e aperta ENTER aqui."""
    with sync_playwright() as p:
        ctx = _chrome_visivel(p)
        try:
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            page.goto(TEAMS_URL)
            print("\n1) Faça o login completo no Teams (e-mail, senha, MFA). Se perguntar 'Manter conectado?', clique em SIM.")
            print("2) Espere o Teams carregar (seu nome aparece no perfil).")
            input("3) Volte aqui e aperte ENTER... ")
            print("Pronto. A sessão ficou salva na pasta do perfil:", sync.PERFIL_DIR)
        finally:
            ctx.close()


def login_automatico(timeout_min=15):
    """Sessão caiu durante uma atualização: abre o Chrome e espera você entrar (sem precisar apertar nada)."""
    definir_estado("aguardando_login")
    log(f"Sessão do Teams expirada. Abri o Chrome: faça o login em até {timeout_min} min.")
    with sync_playwright() as p:
        ctx = _chrome_visivel(p)
        try:
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            page.goto(TEAMS_URL, wait_until="domcontentloaded", timeout=60000)
            fim, seguidos = time.time() + timeout_min * 60, 0
            while time.time() < fim:
                time.sleep(5)
                try:
                    logado = (not sync.deslogado(page)) and "teams" in page.url
                except Exception:  # página navegando
                    logado = False
                seguidos = seguidos + 1 if logado else 0
                if seguidos >= 8:  # ~40 s seguidos sem tela de login
                    time.sleep(5)
                    log("Login detectado.")
                    return True
            log("Login não concluído a tempo.")
            return False
        finally:
            ctx.close()


# ---------- sincronização ----------
def rodar(rcs, projeto_id, origem):
    definir_estado("executando")
    try:
        r = sync.sincronizar(rcs, projeto_id, local=True, origem=origem, cancelar=parar_solicitado)
        if r["status"] == "sessao_expirada" and login_automatico():
            definir_estado("executando")
            r = sync.sincronizar(rcs, projeto_id, local=True, origem=origem, cancelar=parar_solicitado)
        log(f"Resultado: {r['status']} · {r['total']} itens · {r['mensagem'][:200]}")
        return r
    finally:
        limpar_parar()
        definir_estado("ocioso")


def _hm(txt):
    h, m = txt.split(":")
    return int(h) * 60 + int(m)


def na_janela(dt):
    if dt.weekday() not in DIAS_AUTO:
        return False
    minutos = dt.hour * 60 + dt.minute
    return _hm(JANELA_INI) <= minutos < _hm(JANELA_FIM)


def ja_atualizou_hoje():
    """Houve atualização completa (todos os projetos) com sucesso hoje, daqui ou do GitHub?"""
    meia_noite = datetime.now().astimezone().replace(hour=0, minute=0, second=0, microsecond=0)
    rows = rest("GET", f"exiros_sync_log?status=eq.ok&projeto_id=is.null&finalizado_em=gte.{_iso_z(meia_noite)}&select=id&limit=1")
    return bool(rows)


# ---------- pedidos do app ----------
def proximo_pedido():
    limite = _iso_z(datetime.now(timezone.utc) - timedelta(minutes=PEDIDO_VALIDADE_MIN))
    rest("PATCH", f"exiros_pedidos?status=eq.pendente&criado_em=lt.{limite}",
         {"status": "expirado", "finalizado_em": agora(), "mensagem": "Expirou: o agente local estava fora do ar."},
         prefer="return=minimal")
    rows = rest("GET", "exiros_pedidos?status=eq.pendente&order=id.asc&limit=1")
    return rows[0] if rows else None


def reservar(pedido_id):
    r = rest("PATCH", f"exiros_pedidos?id=eq.{pedido_id}&status=eq.pendente",
             {"status": "executando", "iniciado_em": agora()}, prefer="return=representation")
    return bool(r)


_auto = {"dia": None, "n": 0, "ultima": 0.0}


def ciclo():
    ped = proximo_pedido()
    if ped:
        if reservar(ped["id"]):
            log(f"Pedido #{ped['id']} do app" + (f" (projeto {ped['projeto_id']})" if ped.get("projeto_id") else " (todos os projetos)"))
            rcs = [re.sub(r"\D", "", x) for x in re.split(r"[,; ]+", ped.get("rcs") or "") if x.strip()]
            r = rodar(rcs or None, ped.get("projeto_id"), "local")
            rest("PATCH", f"exiros_pedidos?id=eq.{ped['id']}",
                 {"status": r["status"], "finalizado_em": agora(), "mensagem": (r["mensagem"] or "")[:500]},
                 prefer="return=minimal")
        return

    agora_l = datetime.now()
    if not na_janela(agora_l):
        return
    if _auto["dia"] != agora_l.date():
        _auto.update(dia=agora_l.date(), n=0, ultima=0.0)
    if _auto["n"] >= AUTO_MAX_TENTATIVAS or time.time() - _auto["ultima"] < AUTO_INTERVALO_MIN * 60:
        return
    if ja_atualizou_hoje():
        return
    _auto["n"] += 1
    _auto["ultima"] = time.time()
    log(f"Atualização automática (tentativa {_auto['n']} de {AUTO_MAX_TENTATIVAS} hoje)")
    rodar(None, None, "local-auto")


# ---------- principal ----------
def instancia_unica():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", PORTA_TRAVA))
    except OSError:
        return None
    return s  # manter a referência viva até o fim do programa


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--login", action="store_true", help="só faz o login no Teams (Chrome visível)")
    ap.add_argument("--agora", action="store_true", help="atualiza tudo agora e sai")
    args = ap.parse_args()

    trava = instancia_unica()

    if args.login:
        if trava is None:
            print("Feche a janela do agente (Exiros Local) antes de fazer o login: o Chrome do perfil está em uso.")
            return 3
        login_manual()
        return 0

    if args.agora:
        if trava is None:  # agente aberto: ele é o dono do Chrome, então só pedimos a ele
            rest("POST", "exiros_pedidos", {"solicitado_por": "atalho no PC", "status": "pendente"}, prefer="return=minimal")
            print("O agente já está aberto: pedido enviado. Acompanhe pela janela dele ou pelo app.")
            return 0
        r = rodar(None, None, "local")
        return 0 if r["status"] == "ok" else 1

    if trava is None:
        print("Já existe um agente rodando neste computador.")
        return 3

    threading.Thread(target=_batimento_loop, daemon=True).start()
    dias = ",".join(["seg", "ter", "qua", "qui", "sex", "sáb", "dom"][d] for d in sorted(DIAS_AUTO))
    log(f"Agente local {VERSAO} iniciado em {MAQUINA}. Automático: {JANELA_INI}-{JANELA_FIM} ({dias}). Feche esta janela para parar.")
    definir_estado("ocioso")
    try:
        while True:
            try:
                ciclo()
            except Exception:
                traceback.print_exc()
            time.sleep(POLL_SEG)
    except KeyboardInterrupt:
        log("Agente encerrado.")
        return 3


if __name__ == "__main__":
    sys.exit(main())
