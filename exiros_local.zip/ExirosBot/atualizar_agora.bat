@echo off
title Exiros - atualizar agora
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
if not exist venv\Scripts\python.exe (
  echo Rode o instalar.bat primeiro.
  pause
  exit /b 1
)
venv\Scripts\python.exe agente_local.py --agora
echo.
pause
