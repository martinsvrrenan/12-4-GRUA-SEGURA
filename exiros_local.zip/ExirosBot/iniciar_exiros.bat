@echo off
title Exiros Local
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
if not exist venv\Scripts\python.exe (
  echo Rode o instalar.bat primeiro.
  pause
  exit /b 1
)
:loop
venv\Scripts\python.exe agente_local.py
if %errorlevel%==3 exit /b 0
echo.
echo O agente parou por um erro. Reiniciando em 30 segundos... (feche esta janela para sair)
timeout /t 30 /nobreak >nul
goto loop
