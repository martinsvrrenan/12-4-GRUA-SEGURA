@echo off
title Exiros Local - instalacao
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
echo ==== Instalacao do Exiros Local ====
echo.

set PY=
where py >nul 2>nul && set PY=py -3
if "%PY%"=="" (
  where python >nul 2>nul && set PY=python
)
if "%PY%"=="" (
  echo Python nao encontrado. Instale em python.org/downloads marcando "Add python.exe to PATH" e rode de novo.
  pause
  exit /b 1
)

if not exist venv\Scripts\python.exe (
  echo Criando ambiente...
  %PY% -m venv venv
)
echo Instalando dependencias...
venv\Scripts\python.exe -m pip install --upgrade pip >nul
venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
  echo Falha ao instalar as dependencias.
  pause
  exit /b 1
)

if not exist .env (
  copy .env.exemplo .env >nul
  echo.
  echo Vai abrir o arquivo .env: preencha SUPABASE_URL e SUPABASE_SERVICE_KEY, salve e feche.
  notepad .env
)

echo.
echo Login no Teams: vai abrir o Chrome. Entre com sua conta e volte aqui.
venv\Scripts\python.exe agente_local.py --login

echo.
echo Criando atalho na pasta Inicializar do Windows (o agente abre sozinho quando voce ligar o PC)...
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\ExirosLocal.lnk'); $s.TargetPath='%~dp0iniciar_exiros.bat'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.Save()"

echo.
echo Pronto! Para iniciar agora, de dois cliques em iniciar_exiros.bat.
pause
